/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package genreclass;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import static java.lang.Character.isDigit;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Scanner;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.text.WordUtils;

/**
 *
 * @author Uglybear
 */
public class GenreClass {

    /**
     * @param args the command line arguments
     */
    
    static String songName, genreInput, confirm, directory, filePath;
    static String[] genre = new String[] {"Pop", "Electronic", "Metal", "Heavy Rock", "Rock", "Blues", "Jazz", "Country", "Orchestral"};  

    public static void main(String[] args) {
        
         
        
        Scanner userInput01 = new Scanner(System.in);
        
        // This application is standalone and therefore cannot use relative path to the Moodra java folder
        // Example path: C://Users/Uglybear/Documents/NetBeansProjects/Moodra/music
        System.out.println("Enter the full directory path for where genre.txt is located: ");
        directory = userInput01.next();
        
        //Check if the entered directory is empty or not present
        if(findFile(directory) == false) {
            System.out.println("Error: directory " + directory + " doesn't exist, is empty or doesn't contain genre.txt!");
            
            System.out.println("Enter the full directory path for where genre.txt is located: ");
            directory = userInput01.next();
        } 
        else
        {
            categorise();
        }
        
    }
    
    // Normalises the music files
    // All music files must follow a specific naming convention otherwise code wont work (i.e Kalmiba or Maid With Flaxen Hair)
    static String captLetter(String word)
    {
        String wordLC = word.toLowerCase();
        return (WordUtils.capitalizeFully(wordLC));
    }
    
    // Check if song exists within Moodra/music
    static boolean findSong(String[] files, String songName)
    {
        int i = 0;
        boolean check = false;
        
        while (check == false)
        {
                
            String temp = files[i];

            if (temp.equals(songName))
            {
                check = true;
            }
            else
            {
                if (i == (files.length - 1))
                {
                    System.out.println("I'm sorry but that file doesn't exist!");
                    return false;
                } 
                else {
                    i++;
                }
            }
        }
        
        return true;
    }
    
    // Find the song in genre.txt 
    static boolean findSongText(String songName)
    {
       try {
           
           BufferedReader bReader = new BufferedReader(new FileReader("C://Users/Uglybear/My Documents/NetBeansProjects/Moodra/music/genre.txt"));
           
           int lineCount = 0;
           String line = "";
           
           while((line = bReader.readLine()) != null)
           {
               
               lineCount++;
               
               int posFound = line.indexOf(songName);
               
               if (posFound > -1)
               {
                   bReader.close();
                   return true;
               }
           }
           
           bReader.close();
           return false;
       } 
       catch (IOException e)
       {
           System.out.println("Error: " + e.toString());
       }
       
       return false;
    }

    // Hide genre.txt
    static File[] getWavFiles(String directory)
    {
        File folder = new File(directory);
        
        FileFilter fileFilter = new WildcardFileFilter("*.wav");
        File[] files = folder.listFiles(fileFilter);
        
        return files;
    }
    
    // Allows user to decide if they want to add more genre's to other songs
    static void addMoreSongs(Scanner userInput)
    {
        System.out.println("Song has been added, do you want to add another (Y/N)?");
                        
        confirm = userInput.nextLine(); 
                        
        String confirmCapt = captLetter(confirm);
                        
        if (confirm.equals("Y"))
        {
            categorise();
        }
    }
    
    // Find genre.txt
    static public boolean findFile(String filePath)
    {
        File file = new File(filePath);
        FileFilter fileFilter = new WildcardFileFilter("*.txt");
        File[] list = file.listFiles(fileFilter);

        if(list!=null)
        {
           
            for (int i = 0; i < list.length; i++)
            {
                if (list[i].getName().equals("genre.txt"))
                {
                    return true;
                }
            }
        }

        return false;
    }
    
    // Write to genre.txt
    public static void bufferedWritter(String textToAppend, String directory) throws IOException 
    {

        File file = new File(directory);
        FileFilter fileFilter = new WildcardFileFilter("*.txt");
        File[] list = file.listFiles(fileFilter);
        
        for (int i = 0; i < list.length; i++)
            {
                if (list[i].getName().equals("genre.txt"))
                {
                    filePath = list[i].toString();
                }
        }
        
        BufferedWriter writer = new BufferedWriter(
                                new FileWriter(filePath, true)  //Set true for append mode
                            );  
        writer.newLine();   //Add new line
        writer.write(textToAppend);
        writer.close();
    }
    
    // Add song name and user decided category to a text file called genre.txt
    static void categorise()
    {
        
        System.out.println(directory);
        
        Scanner userInput = new Scanner(System.in);
        
        File[] fileFiles = getWavFiles(directory); 
        String[] files = new String[fileFiles.length];

        for (int i = 0; i < files.length; i++) {
            files[i] = fileFiles[i].getName();
        }

        // Print all songs in the directory
        System.out.println("Here are the current songs in the music directory: ");

        for (int i = 0; i < files.length; i++)
        {
            String temp = files[i];
            files[i] = FilenameUtils.removeExtension(temp);
            System.out.println(files[i]);
        }
        
        System.out.println("Please enter the song name: ");
        songName = userInput.nextLine(); 
        
        String songNameCapt = captLetter(songName);
        
        System.out.println(songNameCapt);
        
        // Check if song exists
        if (findSong(files, songNameCapt) == false)
        {
            System.out.println("That file doesn't exist");
            addMoreSongs(userInput);
        }
        else if (findSongText(songNameCapt) == true)
        {
            System.out.println("That song already has an index!");
            addMoreSongs(userInput);
        }
        else
        {
            System.out.println("Please select the corresponding number for the genre from the following list:" + "\n");  
            
            for (int a = 0; a < genre.length; a++)
            {
                System.out.println(a + " " + genre[a]);
            }
            
            genreInput = userInput.nextLine(); 

            try {
                
                int genreInt = Integer.parseInt(genreInput);
                
                if (genreInt >= genre.length)
                {
                    System.out.println("You did not enter a number from the list");
                    addMoreSongs(userInput);
                }
                else
                {
                    
                    String songGenre = songNameCapt + " " + genre[genreInt];
                    
                    try 
                    {
                        bufferedWritter(songGenre, directory);
                        addMoreSongs(userInput);
                    }
                    catch (IOException e) 
                    {
                        System.out.println("Error: " + e.toString());
                    }
                }
                
            // Error if user didn't enter a number
            } catch (NumberFormatException e) {
                System.out.println("You did not enter a number");
                addMoreSongs(userInput);
            }
        } 
    }
    
}
